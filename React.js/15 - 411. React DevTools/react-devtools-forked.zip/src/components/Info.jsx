import React from "react";

function Info(props) {
  return <p className="info">{props.contactInfo}</p>;
}

export default Info;
